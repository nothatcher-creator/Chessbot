# ACAS Android Bridge Milestone 1 Design

Milestone 1 proves reliable position detection over normal Chrome and the native Lichess Android app before any chess engine is added. The app is a separate Android companion. It requests Accessibility permission only for `com.android.chrome` and `org.lichess.mobileV2`, reads visible move-list text when available, reconstructs standard-chess FEN from SAN, and reports target app, FEN, side to move, node count, and move count.

MediaProjection is a fallback, not the primary position source. It detects an axis-aligned 8x8 board using checker-color geometry, estimates orientation from top/bottom piece luminance, and recognizes the untouched starting occupancy pattern. If Accessibility provides SAN moves, that FEN takes precedence. If only screen geometry is available after moves have begun, the app reports the board as detected but leaves FEN unknown rather than guessing pieces.

A small `TYPE_APPLICATION_OVERLAY` diagnostics panel mirrors the state. The overlay is hidden briefly before processing a screen-capture frame so the detector never samples its own UI. This milestone contains no Stockfish, no move recommendations, and no automated input.

The app is prepared as an ACAS-derived Android companion under GPL-compatible terms, but milestone 1 does not copy A.C.A.S. userscript code; later milestones can port selected GPL-3.0 components with attribution and corresponding source.
