# ACAS Android Bridge Milestone 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build an installable Android APK that detects Lichess in Chrome or the native Lichess app, reconstructs FEN from visible SAN when Accessibility exposes it, and falls back to screen board geometry.

**Architecture:** Android Accessibility is the primary data source. A MediaProjection foreground service detects board geometry/orientation and the untouched starting layout as a fallback. Shared immutable detector state feeds both the main Activity and a floating diagnostics overlay.

**Tech Stack:** Java 17, Android SDK 36, AGP 8.13.0, chesslib 1.3.7, JUnit 4.

**Spec:** `docs/superpowers/specs/2026-09-18-acas-android-m1-design.md`

## Global Constraints
- Detection only; no engine or move recommendations in milestone 1.
- Accessibility is restricted to Chrome and Lichess Mobile V2.
- Screen capture must hide the diagnostics overlay before sampling.
- Never invent a FEN from screen pixels after the starting layout changes.

### Task 1: Core target/move/board-state logic
Create `TargetAppClassifier`, `SanTokenExtractor`, `ScreenBoardHeuristics`, and `BoardStateResolver` with JVM tests covering target packages, duplicate Accessibility text, standard SAN replay, starting occupancy, and orientation thresholds.

### Task 2: Accessibility bridge
Create `AcasAccessibilityService` and `AccessibilitySnapshotReader`; restrict the service XML to Chrome/Lichess and publish SAN-derived FEN into `DetectorState`.

### Task 3: MediaProjection fallback
Create `BoardGeometryDetector` and `ProjectionService`; use grid-parity color scoring, orientation brightness, starting occupancy, and an 80 ms overlay-hide handshake.

### Task 4: Diagnostics UI
Create `MainActivity` and `OverlayService` with permission buttons and live target/source/board/FEN/turn/orientation/move/node diagnostics.

### Task 5: CI/package verification
Build with Gradle 8.13, run unit tests, assemble debug APK, verify ZIP integrity, manifest/classes, and upload the APK artifact.
