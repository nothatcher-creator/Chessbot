package com.nothatcher.acasbridge;

import static org.junit.Assert.*;
import org.junit.Test;

public class ScreenBoardHeuristicsTest {
    @Test public void onlyBootstrapsAnUnmovedOccupancyPattern() {
        boolean[][] occupied = new boolean[8][8];
        for (int c = 0; c < 8; c++) occupied[0][c] = occupied[1][c] = occupied[6][c] = occupied[7][c] = true;
        assertTrue(ScreenBoardHeuristics.looksLikeStartingOccupancy(occupied));
        occupied[6][4] = false;
        occupied[4][4] = true;
        assertFalse(ScreenBoardHeuristics.looksLikeStartingOccupancy(occupied));
    }

    @Test public void infersOrientationOnlyWhenBrightnessIsDecisive() {
        assertEquals("White bottom", ScreenBoardHeuristics.orientationFromLuminance(45, 210));
        assertEquals("Black bottom", ScreenBoardHeuristics.orientationFromLuminance(210, 45));
        assertEquals("Unknown", ScreenBoardHeuristics.orientationFromLuminance(100, 110));
    }
}
