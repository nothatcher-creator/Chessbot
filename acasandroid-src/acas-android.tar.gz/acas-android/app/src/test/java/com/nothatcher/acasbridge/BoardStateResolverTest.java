package com.nothatcher.acasbridge;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.Test;

public class BoardStateResolverTest {
    @Test public void reconstructsFenFromVisibleSanMoves() {
        BoardStateResolver.Result r = BoardStateResolver.fromSan(List.of("e4", "e5", "Nf3", "Nc6"));
        assertTrue(r.ok());
        assertEquals("White", r.sideToMove());
        assertTrue(r.fen().startsWith("r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w"));
    }
}
