package com.nothatcher.acasbridge;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.Test;

public class SanTokenExtractorTest {
    @Test public void prefersFullMoveLineOverDuplicateChildNodes() {
        assertEquals(List.of("e4", "e5", "Nf3", "Nc6"),
                SanTokenExtractor.extract(List.of("1. e4 e5 2. Nf3 Nc6", "Nf3", "Nc6")));
    }

    @Test public void reconstructsIndividualMoveNodes() {
        assertEquals(List.of("e4", "e5", "Nf3", "Nc6"),
                SanTokenExtractor.extract(List.of("1.", "e4", "e5", "2.", "Nf3", "Nc6", "1-0")));
    }
}
