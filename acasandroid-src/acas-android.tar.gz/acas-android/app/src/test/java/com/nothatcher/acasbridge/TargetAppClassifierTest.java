package com.nothatcher.acasbridge;

import static org.junit.Assert.*;
import org.junit.Test;

public class TargetAppClassifierTest {
    @Test public void recognizesChromeAndLichessV2() {
        assertEquals(TargetAppClassifier.Target.CHROME, TargetAppClassifier.classify("com.android.chrome"));
        assertEquals(TargetAppClassifier.Target.LICHESS_APP, TargetAppClassifier.classify("org.lichess.mobileV2"));
        assertEquals(TargetAppClassifier.Target.OTHER, TargetAppClassifier.classify("com.other"));
    }
}
