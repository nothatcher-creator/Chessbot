package com.nothatcher.acasbridge;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class BoardGeometryDetector {
    public record Detection(Rect rect, double score, String orientation, boolean looksLikeStart) {}

    private BoardGeometryDetector() {}

    public static Detection detect(Bitmap source) {
        if (source == null || source.getWidth() < 240 || source.getHeight() < 400) return null;
        float scale = source.getWidth() > 720 ? 720f / source.getWidth() : 1f;
        Bitmap image = scale < 1f
                ? Bitmap.createScaledBitmap(source, Math.round(source.getWidth() * scale), Math.round(source.getHeight() * scale), true)
                : source;
        int w = image.getWidth();
        int h = image.getHeight();

        double[] fractions = {1.0, 0.98, 0.95, 0.92, 0.90, 0.88, 0.85, 0.82, 0.80, 0.76, 0.72, 0.68, 0.64, 0.60};
        Candidate best = null;
        for (double fraction : fractions) {
            int size = (int) Math.round(w * fraction);
            if (size < 220 || size > h) continue;
            Set<Integer> xs = new LinkedHashSet<>();
            xs.add(0);
            xs.add(Math.max(0, (w - size) / 2));
            xs.add(Math.max(0, w - size));
            int yStep = Math.max(6, size / 72);
            int yMax = h - size;
            for (int x : xs) {
                for (int y = 0; y <= yMax; y += yStep) {
                    Candidate candidate = score(image, x, y, size);
                    if (candidate != null && (best == null || candidate.score > best.score)) best = candidate;
                }
            }
        }

        if (best == null || best.score < 2.2 || best.betweenDistance < 55.0) {
            if (image != source) image.recycle();
            return null;
        }

        boolean[][] occupancy = occupancy(image, best.x, best.y, best.size);
        String orientation = ScreenBoardHeuristics.orientationFromLuminance(
                rowCenterLuminance(image, best.x, best.y, best.size, 0, 1),
                rowCenterLuminance(image, best.x, best.y, best.size, 6, 7));
        boolean start = ScreenBoardHeuristics.looksLikeStartingOccupancy(occupancy);

        float inverse = 1f / scale;
        Rect rect = new Rect(
                Math.round(best.x * inverse), Math.round(best.y * inverse),
                Math.round((best.x + best.size) * inverse), Math.round((best.y + best.size) * inverse));
        Detection out = new Detection(rect, best.score, orientation, start);
        if (image != source) image.recycle();
        return out;
    }

    private record Candidate(int x, int y, int size, double score, double betweenDistance) {}

    private static Candidate score(Bitmap b, int x, int y, int size) {
        double[][] sum = new double[2][3];
        double[][] sumSq = new double[2][3];
        int[] count = new int[2];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                double[] color = squareBackground(b, x, y, size, r, c);
                int p = (r + c) & 1;
                for (int k = 0; k < 3; k++) {
                    sum[p][k] += color[k];
                    sumSq[p][k] += color[k] * color[k];
                }
                count[p]++;
            }
        }
        double within = 0;
        double between = 0;
        for (int k = 0; k < 3; k++) {
            double m0 = sum[0][k] / count[0];
            double m1 = sum[1][k] / count[1];
            between += (m0 - m1) * (m0 - m1);
            within += (sumSq[0][k] / count[0] - m0 * m0) + (sumSq[1][k] / count[1] - m1 * m1);
        }
        within = Math.max(0.0, within);
        double score = between / (1.0 + within);
        return new Candidate(x, y, size, score, Math.sqrt(between));
    }

    private static boolean[][] occupancy(Bitmap b, int x, int y, int size) {
        boolean[][] out = new boolean[8][8];
        double cell = size / 8.0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                double[] bg = squareBackground(b, x, y, size, r, c);
                int px = clamp((int) Math.round(x + (c + 0.5) * cell), 0, b.getWidth() - 1);
                int py = clamp((int) Math.round(y + (r + 0.5) * cell), 0, b.getHeight() - 1);
                int color = b.getPixel(px, py);
                double dr = Color.red(color) - bg[0];
                double dg = Color.green(color) - bg[1];
                double db = Color.blue(color) - bg[2];
                out[r][c] = Math.sqrt(dr * dr + dg * dg + db * db) >= 38.0;
            }
        }
        return out;
    }

    private static double rowCenterLuminance(Bitmap b, int x, int y, int size, int rowA, int rowB) {
        double cell = size / 8.0;
        double sum = 0;
        int count = 0;
        for (int r = rowA; r <= rowB; r++) {
            for (int c = 0; c < 8; c++) {
                int px = clamp((int) Math.round(x + (c + 0.5) * cell), 0, b.getWidth() - 1);
                int py = clamp((int) Math.round(y + (r + 0.5) * cell), 0, b.getHeight() - 1);
                int color = b.getPixel(px, py);
                sum += 0.2126 * Color.red(color) + 0.7152 * Color.green(color) + 0.0722 * Color.blue(color);
                count++;
            }
        }
        return count == 0 ? 0 : sum / count;
    }

    private static double[] squareBackground(Bitmap b, int x, int y, int size, int row, int col) {
        double cell = size / 8.0;
        double[] out = new double[3];
        double[][] offsets = {{0.18,0.18},{0.82,0.18},{0.18,0.82},{0.82,0.82}};
        for (double[] o : offsets) {
            int px = clamp((int) Math.round(x + (col + o[0]) * cell), 0, b.getWidth() - 1);
            int py = clamp((int) Math.round(y + (row + o[1]) * cell), 0, b.getHeight() - 1);
            int color = b.getPixel(px, py);
            out[0] += Color.red(color);
            out[1] += Color.green(color);
            out[2] += Color.blue(color);
        }
        out[0] /= 4.0; out[1] /= 4.0; out[2] /= 4.0;
        return out;
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
