package com.nothatcher.acasbridge;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;

public final class ProjectionService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "acas_capture";

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread workerThread;
    private Handler worker;
    private long lastProcessed;
    private boolean waitingForCleanFrame;
    private long hideRequestedAt;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "ACAS screen detection", NotificationManager.IMPORTANCE_LOW));
        }
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setContentTitle("ACAS Android Bridge")
                .setContentText("Detecting Lichess board geometry")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
        startForeground(41, notification);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (projection != null || intent == null) return START_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY; }

        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { cleanup(); stopSelf(); }
        }, new Handler(Looper.getMainLooper()));

        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect bounds = Build.VERSION.SDK_INT >= 30 ? wm.getMaximumWindowMetrics().getBounds() : new Rect(0,0,
                getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels);
        int width = bounds.width();
        int height = bounds.height();
        int density = getResources().getDisplayMetrics().densityDpi;

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        workerThread = new HandlerThread("acas-capture");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        reader.setOnImageAvailableListener(this::onImage, worker);
        display = projection.createVirtualDisplay("ACAS-Board-Detector", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, worker);
        return START_STICKY;
    }

    private void onImage(ImageReader imageReader) {
        long now = SystemClock.elapsedRealtime();
        Image image = imageReader.acquireLatestImage();
        if (image == null) return;
        try {
            if (!waitingForCleanFrame) {
                OverlayService.setCaptureHidden(true);
                waitingForCleanFrame = true;
                hideRequestedAt = now;
                return;
            }
            if (now - hideRequestedAt < 80) return;
            if (now - lastProcessed < 800) return;
            lastProcessed = now;

            Bitmap bitmap = imageToBitmap(image);
            if (bitmap == null) return;
            BoardGeometryDetector.Detection detection = BoardGeometryDetector.detect(bitmap);
            bitmap.recycle();
            if (detection != null) {
                Rect r = detection.rect();
                DetectorState.mergeScreen(true, detection.orientation(),
                        r.left + "," + r.top + " " + r.width() + "x" + r.height(),
                        detection.looksLikeStart(),
                        detection.looksLikeStart()
                                ? "Board geometry + starting occupancy detected."
                                : "Board geometry detected; waiting for move text to reconstruct FEN.");
            } else {
                DetectorState.mergeScreen(false, null, null, false, "Screen capture active; board not found yet.");
            }
        } finally {
            image.close();
            if (waitingForCleanFrame && now - hideRequestedAt >= 80) {
                waitingForCleanFrame = false;
                OverlayService.setCaptureHidden(false);
            }
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth();
        int height = image.getHeight();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        int paddedWidth = width + rowPadding / pixelStride;
        Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
        if (cropped != padded) padded.recycle();
        return cropped;
    }

    private void cleanup() {
        OverlayService.setCaptureHidden(false);
        if (reader != null) reader.close();
        if (display != null) display.release();
        if (projection != null) projection.stop();
        if (workerThread != null) workerThread.quitSafely();
        reader = null; display = null; projection = null; workerThread = null; worker = null;
    }

    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
