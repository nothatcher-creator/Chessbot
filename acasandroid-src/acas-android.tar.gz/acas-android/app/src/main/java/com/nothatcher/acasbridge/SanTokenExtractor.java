package com.nothatcher.acasbridge;

import java.util.*;
import java.util.regex.*;

public final class SanTokenExtractor {
  private static final Pattern SAN = Pattern.compile(
      "^(?:O-O-O|O-O|[KQRBN](?:[a-h1-8]{0,2})x?[a-h][1-8](?:=[QRBN])?|[a-h](?:x[a-h])?[1-8](?:=[QRBN])?)[+#]?[!?]*$",
      Pattern.CASE_INSENSITIVE);
  private static final Pattern MOVE_NUMBER = Pattern.compile("^\\d+\\.{1,3}$");

  private SanTokenExtractor() {}

  public static List<String> extract(List<String> texts) {
    if (texts == null || texts.isEmpty()) return List.of();
    List<List<String>> candidates = new ArrayList<>();
    List<String> singles = new ArrayList<>();

    for (String raw : texts) {
      if (raw == null || raw.isBlank()) continue;
      List<String> parsed = parseLine(raw);
      if (parsed.size() >= 2) candidates.add(parsed);
      else if (parsed.size() == 1) singles.add(parsed.get(0));
    }

    if (!candidates.isEmpty()) {
      candidates.sort((a, b) -> Integer.compare(b.size(), a.size()));
      return List.copyOf(candidates.get(0));
    }

    List<String> out = new ArrayList<>();
    String prev = null;
    for (String move : singles) {
      if (!move.equals(prev)) out.add(move);
      prev = move;
    }
    return List.copyOf(out);
  }

  static List<String> parseLine(String raw) {
    String normalized = raw
        .replace('\u00A0', ' ')
        .replace("…", "...")
        .replace("0-0-0", "O-O-O")
        .replace("0-0", "O-O")
        .replaceAll("(?m)^\\s*[a-zA-Z0-9_\\-]{2,30}\\s*$", "$0");

    String[] tokens = normalized.split("\\s+");
    List<String> moves = new ArrayList<>();
    for (String token : tokens) {
      String t = token.trim();
      if (t.isEmpty()) continue;
      t = t.replaceAll("^\\d+\\.(?:\\.\\.)?", "");
      if (t.isEmpty() || MOVE_NUMBER.matcher(t).matches()) continue;
      if (t.equals("1-0") || t.equals("0-1") || t.equals("1/2-1/2") || t.equals("*")) continue;
      t = t.replaceAll("^[({]+|[)};,]+$", "");
      if (SAN.matcher(t).matches()) {
        moves.add(normalizeSan(t));
      }
    }
    return moves;
  }

  private static String normalizeSan(String san) {
    String s = san.replace("0-0-0", "O-O-O").replace("0-0", "O-O");
    return s.replaceAll("[!?]+$", "");
  }
}
