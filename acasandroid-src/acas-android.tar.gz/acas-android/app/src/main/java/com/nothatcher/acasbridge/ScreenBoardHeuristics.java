package com.nothatcher.acasbridge;

public final class ScreenBoardHeuristics {
  private ScreenBoardHeuristics() {}

  public static boolean looksLikeStartingOccupancy(boolean[][] occupied) {
    if (occupied == null || occupied.length != 8) return false;
    for (boolean[] row : occupied) if (row == null || row.length != 8) return false;

    int outerOccupied = 0;
    int middleOccupied = 0;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (!occupied[r][c]) continue;
        if (r <= 1 || r >= 6) outerOccupied++; else middleOccupied++;
      }
    }
    return outerOccupied >= 28 && middleOccupied == 0;
  }

  public static String orientationFromLuminance(double top, double bottom) {
    double delta = bottom - top;
    if (delta >= 30.0) return "White bottom";
    if (delta <= -30.0) return "Black bottom";
    return "Unknown";
  }
}
