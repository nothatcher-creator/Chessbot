package com.nothatcher.acasbridge;

import com.github.bhlangonijr.chesslib.Board;
import java.util.List;

public final class BoardStateResolver {
    public record Result(String fen, String sideToMove, int appliedMoves, String error) {
        public boolean ok() { return error == null; }
    }

    private BoardStateResolver() {}

    public static Result fromSan(List<String> moves) {
        Board board = new Board();
        int applied = 0;
        try {
            for (String san : moves) {
                if (!board.doMove(san)) {
                    return new Result(null, "Unknown", applied, "Rejected move: " + san);
                }
                applied++;
            }
            String side = board.getSideToMove().name().equals("WHITE") ? "White" : "Black";
            return new Result(board.getFen(), side, applied, null);
        } catch (RuntimeException e) {
            return new Result(null, "Unknown", applied, "Move parse failunty, applied, null);
  ();
  P.ager.TDove :n", appd Math.min(ma.Aspl]sm                                                                                                                              