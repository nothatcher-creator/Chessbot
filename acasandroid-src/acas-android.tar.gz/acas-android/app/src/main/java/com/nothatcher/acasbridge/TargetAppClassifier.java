package com.nothatcher.acasbridge;

public final class TargetAppClassifier {
  public enum Target { CHROME, LICHESS_APP, OTHER }

  private TargetAppClassifier() {}

  public static Target classify(String packageName) {
    if (packageName == null) return Target.OTHER;
    if (packageName.equals("org.lichess.mobileV2") || packageName.equals("org.lichess.mobileV2.debug")) {
      return Target.LICHESS_APP;
    }
    if (packageName.equals("com.android.chrome") || packageName.equals("com.chrome.beta") ||
        packageName.equals("com.chrome.dev") || packageName.equals("com.chrome.canary")) {
      return Target.CHROME;
    }
    return Target.OTHER;
  }

  public static String label(Target target) {
    return switch (target) {
      case CHROME -> "Lichess in Chrome";
      case LICHESS_APP -> "Lichess app";
      case OTHER -> "Other app";
    };
  }
}
